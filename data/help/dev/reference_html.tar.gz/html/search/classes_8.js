var searchData=
[
  ['opencvreader_0',['openCvReader',['../classsrc_1_1cadreur_1_1openCvReader.html',1,'src::cadreur']]]
];
